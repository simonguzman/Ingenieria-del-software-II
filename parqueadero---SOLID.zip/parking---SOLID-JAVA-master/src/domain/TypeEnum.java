package domain;

public enum TypeEnum {
    CAR,
    MOTO,
    TRUCK
}